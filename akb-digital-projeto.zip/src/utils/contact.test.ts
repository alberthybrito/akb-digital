import test from 'node:test';
import assert from 'node:assert/strict';
import { PROJECTS } from '../data/portfolioData';
import {
  buildLeadWhatsAppMessage,
  buildServiceWhatsAppUrl,
  buildWhatsAppUrl,
  filterProjectsByCategory,
  formatBrazilianPhone,
  validateContactForm,
} from './contact';

test('buildWhatsAppUrl formats Brazilian number 82921403167 with country code 55 and encodes message', () => {
  const url = buildWhatsAppUrl('Olá AKB Digital!');
  assert.equal(url, 'https://wa.me/5582921403167?text=Ol%C3%A1%20AKB%20Digital!');
});

test('buildServiceWhatsAppUrl embeds the selected service name cleanly', () => {
  const url = buildServiceWhatsAppUrl('Páginas de vendas de alta conversão');
  assert.ok(url.startsWith('https://wa.me/5582921403167?text='));
  assert.ok(decodeURIComponent(url).includes('Páginas de vendas de alta conversão'));
});

test('formatBrazilianPhone formats 10-digit and 11-digit numbers properly', () => {
  assert.equal(formatBrazilianPhone('82921403167'), '(82) 92140-3167');
  assert.equal(formatBrazilianPhone('8232214567'), '(82) 3221-4567');
  assert.equal(formatBrazilianPhone('829'), '(82) 9');
  assert.equal(formatBrazilianPhone(''), '');
});

test('validateContactForm rejects invalid fields and accepts valid lead data', () => {
  const invalidErrors = validateContactForm({
    name: 'A',
    phone: '123',
    businessSegment: '',
    service: '',
    message: 'Oi',
  });
  assert.ok(invalidErrors.name);
  assert.ok(invalidErrors.phone);
  assert.ok(invalidErrors.service);
  assert.ok(invalidErrors.message);

  const validErrors = validateContactForm({
    name: 'Mariana Souza',
    phone: '(82) 99988-7766',
    businessSegment: 'Clínica Médica',
    service: 'Criação de sites profissionais',
    message: 'Preciso de um site novo com foco em agendamentos no WhatsApp.',
  });
  assert.deepEqual(validErrors, {});
});

test('buildLeadWhatsAppMessage builds structured Portuguese summary', () => {
  const message = buildLeadWhatsAppMessage({
    name: 'Carlos Eduardo',
    phone: '(11) 98765-4321',
    businessSegment: 'Escritório de Contabilidade',
    service: 'SEO local e presença no Google',
    message: 'Quero melhorar nosso posicionamento no Google na zona sul.',
  });
  assert.ok(message.includes('Carlos Eduardo'));
  assert.ok(message.includes('Escritório de Contabilidade'));
  assert.ok(message.includes('SEO local e presença no Google'));
});

test('filterProjectsByCategory filters accurately and returns all for todos', () => {
  assert.equal(filterProjectsByCategory(PROJECTS, 'todos').length, PROJECTS.length);
  const landingPages = filterProjectsByCategory(PROJECTS, 'landing-pages');
  assert.equal(landingPages.length, 2);
  assert.ok(landingPages.every((item) => item.category === 'landing-pages'));
});
