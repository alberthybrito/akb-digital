import type { ProjectCategory, ProjectItem } from '../data/portfolioData';

export const WHATSAPP_NUMBER = '82921403167';
export const WHATSAPP_DISPLAY = '(82) 92140-3167';
export const INSTAGRAM_HANDLE = 'akb_digital';
export const INSTAGRAM_URL = 'https://instagram.com/akb_digital';

export interface ContactFormValues {
  name: string;
  phone: string;
  businessSegment: string;
  service: string;
  message: string;
}

export interface ContactFormErrors {
  name?: string;
  phone?: string;
  service?: string;
  message?: string;
}

export function sanitizeDigits(value: string): string {
  return value.replace(/\D/g, '');
}

export function formatBrazilianPhone(value: string): string {
  const digits = sanitizeDigits(value).slice(0, 11);
  if (digits.length === 0) return '';
  if (digits.length <= 2) return `(${digits}`;
  if (digits.length <= 6) return `(${digits.slice(0, 2)}) ${digits.slice(2)}`;
  if (digits.length <= 10) {
    return `(${digits.slice(0, 2)}) ${digits.slice(2, 6)}-${digits.slice(6)}`;
  }
  return `(${digits.slice(0, 2)}) ${digits.slice(2, 7)}-${digits.slice(7)}`;
}

export function buildWhatsAppUrl(
  message = 'Olá, equipe AKB Digital! Gostaria de solicitar um orçamento gratuito para o meu projeto.',
  phone = WHATSAPP_NUMBER,
): string {
  const digits = sanitizeDigits(phone);
  const fullNumber = digits.startsWith('55') && digits.length >= 12 ? digits : `55${digits}`;
  return `https://wa.me/${fullNumber}?text=${encodeURIComponent(message)}`;
}

export function buildServiceWhatsAppUrl(serviceTitle: string): string {
  return buildWhatsAppUrl(
    `Olá, AKB Digital! Tenho interesse em solicitar um orçamento gratuito para: ${serviceTitle}.`,
  );
}

export function buildLeadWhatsAppMessage(values: ContactFormValues): string {
  const lines = [
    'Olá, equipe AKB Digital! Gostaria de solicitar um orçamento gratuito.',
    `Nome: ${values.name.trim()}`,
    `WhatsApp: ${values.phone.trim()}`,
  ];

  if (values.businessSegment.trim()) {
    lines.push(`Segmento: ${values.businessSegment.trim()}`);
  }

  lines.push(`Serviço de interesse: ${values.service.trim()}`);

  if (values.message.trim()) {
    lines.push(`Detalhes do projeto: ${values.message.trim()}`);
  }

  return lines.join('\n');
}

export function validateContactForm(values: ContactFormValues): ContactFormErrors {
  const errors: ContactFormErrors = {};
  const trimmedName = values.name.trim();
  const phoneDigits = sanitizeDigits(values.phone);

  if (trimmedName.length < 2) {
    errors.name = 'Informe seu nome completo para personalizarmos o atendimento.';
  }

  if (phoneDigits.length < 10 || phoneDigits.length > 11) {
    errors.phone = 'Informe um número de WhatsApp válido com DDD (10 ou 11 dígitos).';
  }

  if (!values.service.trim()) {
    errors.service = 'Selecione o serviço principal que você procura.';
  }

  if (values.message.trim().length < 10) {
    errors.message = 'Descreva brevemente o seu negócio ou objetivo (mínimo 10 caracteres).';
  }

  return errors;
}

export function filterProjectsByCategory(
  projects: ProjectItem[],
  category: ProjectCategory,
): ProjectItem[] {
  if (category === 'todos') {
    return projects;
  }
  return projects.filter((project) => project.category === category);
}
