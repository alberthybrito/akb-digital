import { useState } from 'react';
import { AboutSection } from './components/AboutSection';
import { ContactSection } from './components/ContactSection';
import { FloatingWhatsApp } from './components/FloatingWhatsApp';
import { Footer } from './components/Footer';
import { Header } from './components/Header';
import { HeroSection } from './components/HeroSection';
import { PortfolioSection } from './components/PortfolioSection';
import { ServicesSection } from './components/ServicesSection';
import { TestimonialsSection } from './components/TestimonialsSection';

export default function App() {
  const [preselectedService, setPreselectedService] = useState<string>('');

  const handleSelectServiceForForm = (serviceTitle: string) => {
    setPreselectedService(serviceTitle);
    const contactEl = document.getElementById('contato');
    if (contactEl) {
      contactEl.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  return (
    <div className="min-h-screen bg-white text-[#0A0D14]">
      <Header />
      <main>
        <HeroSection />
        <AboutSection />
        <ServicesSection onSelectServiceForForm={handleSelectServiceForForm} />
        <PortfolioSection />
        <TestimonialsSection />
        <ContactSection preselectedService={preselectedService} />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </div>
  );
}
