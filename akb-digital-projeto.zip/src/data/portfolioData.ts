export type ProjectCategory = 'todos' | 'sites' | 'landing-pages' | 'seo-redesign';

export interface ServiceItem {
  id: string;
  number: string;
  title: string;
  shortLabel: string;
  description: string;
  outcome: string;
  featured?: boolean;
}

export interface DifferentiatorItem {
  number: string;
  title: string;
  detail: string;
}

export interface ProjectItem {
  id: string;
  title: string;
  client: string;
  segment: string;
  category: Exclude<ProjectCategory, 'todos'>;
  categoryLabel: string;
  year: string;
  primaryMetric: string;
  summary: string;
  challenge: string;
  solution: string;
  deliverables: string[];
  mockupTheme: 'navy' | 'light' | 'ink' | 'slate';
  mockupHeadline: string;
  mockupSubline: string;
  mockupKpis: Array<{ label: string; value: string }>;
}

export interface TestimonialItem {
  id: string;
  quote: string;
  outcome: string;
  author: string;
  role: string;
  company: string;
  location: string;
}

export const HERO_METRICS = [
  { value: 'Até 7 dias úteis', label: 'Entrega ágil do projeto completo' },
  { value: '100% Exclusivo', label: 'Design autoral sem templates genéricos' },
  { value: '98/100 Google', label: 'Velocidade e estrutura otimizada para SEO' },
  { value: 'Aprovação final', label: 'Garantia de ajustes até você aprovar' },
];

export const DIFFERENTIATORS: DifferentiatorItem[] = [
  {
    number: '01',
    title: 'Entrega rápida em até 7 dias úteis',
    detail:
      'Metodologia enxuta e cronograma definido desde o primeiro dia para colocar sua empresa no ar sem meses de espera.',
  },
  {
    number: '02',
    title: 'Design 100% exclusivo (sem templates genéricos)',
    detail:
      'Cada interface é projetada do zero para refletir o posicionamento da sua marca e diferenciar seu negócio da concorrência.',
  },
  {
    number: '03',
    title: 'Otimização máxima para velocidade e Google (SEO)',
    detail:
      'Código limpo, carregamento instantâneo no celular e arquitetura pensada para ranquear nas buscas locais e converter tráfego pago.',
  },
  {
    number: '04',
    title: 'Atendimento próximo e direto com os especialistas',
    detail:
      'Sem intermediários ou filas de suporte: você fala diretamente com quem cria a estratégia, o texto e o código do seu projeto.',
  },
  {
    number: '05',
    title: 'Garantia de ajustes até a sua aprovação final',
    detail:
      'Refinamos cada detalhe visual e textual em etapas transparentes até o site representar exatamente o padrão do seu negócio.',
  },
];

export const SERVICES: ServiceItem[] = [
  {
    id: 'criacao-de-sites',
    number: '01',
    title: 'Criação de sites profissionais',
    shortLabel: 'Criação de sites',
    description:
      'Sites institucionais modernos, responsivos e estruturados para transmitir autoridade imediata a clínicas, escritórios e empresas.',
    outcome: 'Autoridade digital e agendamentos qualificados todos os dias',
    featured: true,
  },
  {
    id: 'paginas-de-vendas',
    number: '02',
    title: 'Páginas de vendas de alta conversão',
    shortLabel: 'Páginas de vendas',
    description:
      'Landing pages focadas em um único objetivo: transformar cliques de anúncios em pedidos de orçamento no seu WhatsApp.',
    outcome: 'Menor custo por lead e maior aproveitamento do tráfego pago',
    featured: true,
  },
  {
    id: 'redesign-otimizacao',
    number: '03',
    title: 'Redesign e otimização de sites',
    shortLabel: 'Redesign e otimização',
    description:
      'Atualização visual, técnica e de usabilidade para sites antigos ou lentos que hoje afastam clientes no celular.',
    outcome: 'Carregamento abaixo de 1s e redução imediata da taxa de rejeição',
  },
  {
    id: 'identidade-visual',
    number: '04',
    title: 'Identidade visual estratégica',
    shortLabel: 'Identidade visual',
    description:
      'Paleta, tipografia e sistema visual consistentes para que sua empresa seja reconhecida com seriedade em todos os canais.',
    outcome: 'Posicionamento sólido que justifica o valor do seu serviço',
  },
  {
    id: 'seo-local',
    number: '05',
    title: 'SEO local e presença no Google',
    shortLabel: 'SEO local',
    description:
      'Estruturação semântica, dados locais e integração estratégica para conectar sua empresa aos clientes que buscam na sua região.',
    outcome: 'Mais ligações e rotas no mapa sem depender apenas de anúncios',
  },
  {
    id: 'copywriting-web',
    number: '06',
    title: 'Copywriting para web',
    shortLabel: 'Copywriting para web',
    description:
      'Textos claros, persuasivos e livres de clichês, escritos para responder às dúvidas reais do cliente e conduzir ao contato.',
    outcome: 'Comunicação objetiva que gera confiança antes mesmo da conversa',
  },
];

export const PORTFOLIO_CATEGORIES: Array<{ id: ProjectCategory; label: string }> = [
  { id: 'todos', label: 'Todos os projetos' },
  { id: 'sites', label: 'Sites institucionais' },
  { id: 'landing-pages', label: 'Páginas de vendas' },
  { id: 'seo-redesign', label: 'SEO local e redesign' },
];

export const PROJECTS: ProjectItem[] = [
  {
    id: 'clinica-vitta-odonto',
    title: 'Portal Institucional e Agendamento Direto',
    client: 'Clínica Odontológica Vitta',
    segment: 'Saúde e Odontologia',
    category: 'sites',
    categoryLabel: 'Site institucional',
    year: '2026',
    primaryMetric: '+164% avaliações agendadas em 90 dias',
    summary:
      'Reestruturação completa da presença digital para clínica de reabilitação oral, com arquitetura voltada para pacientes no celular.',
    challenge:
      'A clínica dependia apenas de indicações e possuía um site lento que não explicava seus tratamentos nem facilitava o contato pelo WhatsApp.',
    solution:
      'Desenvolvemos um site sob medida com navegação limpa por especialidades, copywriting acolhedor para vencer objeções e botões estratégicos de agendamento.',
    deliverables: [
      'Arquitetura de informação e copywriting completo',
      'Design exclusivo mobile-first',
      'Integração direta com WhatsApp e Google Maps',
    ],
    mockupTheme: 'navy',
    mockupHeadline: 'Odontologia de precisão com atendimento humanizado.',
    mockupSubline: 'Implantes, lentes em porcelana e estética dental com planejamento digital.',
    mockupKpis: [
      { label: 'Desempenho mobile', value: '99/100' },
      { label: 'Tempo de carga', value: '0.7s' },
      { label: 'Novos agendamentos', value: '+164%' },
    ],
  },
  {
    id: 'almeida-advocacia',
    title: 'Landing Page para Direito Empresarial e Trabalhista',
    client: 'Henrique Almeida Advocacia',
    segment: 'Profissional Liberal',
    category: 'landing-pages',
    categoryLabel: 'Página de vendas',
    year: '2026',
    primaryMetric: '3.8x mais consultas qualificadas via Google Ads',
    summary:
      'Página de conversão direta projetada para captar empresários que precisam de assessoria jurídica preventiva e contenciosa.',
    challenge:
      'Os anúncios no Google enviavam visitantes para a página inicial genérica, resultando em alto custo por clique e poucos contatos qualificados.',
    solution:
      'Criamos uma página enxuta, com hierarquia tipográfica sóbria em azul marinho e preto, provas de autoridade e qualificação prévia antes do WhatsApp.',
    deliverables: [
      'Landing page de alta velocidade',
      'Copywriting jurídico dentro das normas éticas',
      'Estrutura rastreada para campanhas de Google Ads',
    ],
    mockupTheme: 'ink',
    mockupHeadline: 'Assessoria jurídica estratégica para proteger o seu negócio.',
    mockupSubline: 'Atuação preventiva em contratos, societário e passivo trabalhista.',
    mockupKpis: [
      { label: 'Taxa de conversão', value: '11.4%' },
      { label: 'Retorno em leads', value: '3.8x' },
      { label: 'Prazo de entrega', value: '5 dias' },
    ],
  },
  {
    id: 'lumiere-estetica',
    title: 'Página de Vendas para Protocolos Faciais Premium',
    client: 'Lumière Estética Avançada',
    segment: 'Clínica de Estética',
    category: 'landing-pages',
    categoryLabel: 'Página de vendas',
    year: '2026',
    primaryMetric: 'R$ 68 mil em novos pacotes nos primeiros 45 dias',
    summary:
      'Página dedicada para campanha de protocolos de harmonização e bioestimuladores com foco em público de alto ticket.',
    challenge:
      'Leads chegavam pelo Instagram perguntando apenas preço, sem compreender os diferenciais clínicos e a segurança dos procedimentos.',
    solution:
      'Estruturamos uma narrativa visual elegante que educa o visitante sobre o método, apresenta resultados reais e filtra interessados prontos para avaliação.',
    deliverables: [
      'Design editorial minimalista',
      'Sequência persuasiva de seções e quebra de objeções',
      'Formulário de pré-avaliação conectado ao WhatsApp',
    ],
    mockupTheme: 'light',
    mockupHeadline: 'Naturalidade e ciência aplicadas ao rejuvenescimento facial.',
    mockupSubline: 'Protocolos individualizados conduzidos por equipe biomédica especialista.',
    mockupKpis: [
      { label: 'Ticket médio', value: '+42%' },
      { label: 'Leads qualificados', value: '94/mês' },
      { label: 'Nota PageSpeed', value: '98/100' },
    ],
  },
  {
    id: 'horizonte-engenharia',
    title: 'Redesign Técnico e Posicionamento em SEO Local',
    client: 'Horizonte Engenharia e Obras',
    segment: 'Pequena e Média Empresa',
    category: 'seo-redesign',
    categoryLabel: 'SEO local e redesign',
    year: '2025',
    primaryMetric: 'Top 3 no Google para 14 palavras-chave comerciais',
    summary:
      'Redesign completo de portal corporativo aliado à otimização técnica para buscas regionais de reformas comerciais e laudos.',
    challenge:
      'Site antigo de 2019 não abria corretamente em smartphones e não aparecia nas pesquisas locais quando empresas buscavam construtoras na cidade.',
    solution:
      'Refizemos toda a interface com foco em portfólio de obras executadas, páginas dedicadas por serviço e otimização semântica para SEO local.',
    deliverables: [
      'Redesign completo e identidade digital coesa',
      'Páginas otimizadas para SEO local e Google Meu Negócio',
      'Catálogo interativo de obras entregues',
    ],
    mockupTheme: 'slate',
    mockupHeadline: 'Execução de obras corporativas com prazo e orçamento previsíveis.',
    mockupSubline: 'Projetos comerciais, adequações técnicas e engenharia diagnóstica.',
    mockupKpis: [
      { label: 'Tráfego orgânico', value: '+210%' },
      { label: 'Orçamentos/mês', value: '38 novos' },
      { label: 'Entrega total', value: '7 dias' },
    ],
  },
];

export const TESTIMONIALS: TestimonialItem[] = [
  {
    id: 't1',
    quote:
      'Nosso site antigo parecia amador e quase não trazia pacientes particulares. Em seis dias úteis a AKB Digital entregou uma página elegante, rápida e com textos que explicam exatamente nosso trabalho.',
    outcome: 'Dobramos os pedidos de avaliação pelo WhatsApp logo no segundo mês.',
    author: 'Dra. Camila Vasconcelos',
    role: 'Diretora Clínica',
    company: 'Clínica Odontológica Vitta',
    location: 'Maceió, AL',
  },
  {
    id: 't2',
    quote:
      'O que mais me impressionou foi o atendimento direto e a clareza do copywriting. Eu não precisei escrever nada do zero: eles entenderam meu público jurídico e traduziram minha autoridade para a web.',
    outcome: 'Redução de 40% no custo por contato qualificado nas campanhas do Google.',
    author: 'Dr. Henrique Almeida',
    role: 'Sócio Fundador',
    company: 'Almeida Advocacia Empresarial',
    location: 'Recife, PE',
  },
  {
    id: 't3',
    quote:
      'Contratamos o redesign com foco em SEO local porque éramos invisíveis nas buscas da região. O visual ficou limpo, profissional e hoje recebemos solicitações de orçamento de empresas toda semana.',
    outcome: '14 termos comerciais na primeira página do Google em menos de 4 meses.',
    author: 'Rafael Mendonça',
    role: 'Engenheiro e Diretor',
    company: 'Horizonte Engenharia',
    location: 'Belo Horizonte, MG',
  },
];
