import { useEffect, useState } from 'react';
import { ArrowUpRight, X } from 'lucide-react';
import { AnimatePresence, motion, useReducedMotion } from 'motion/react';
import {
  PORTFOLIO_CATEGORIES,
  PROJECTS,
  type ProjectCategory,
  type ProjectItem,
} from '../data/portfolioData';
import { buildWhatsAppUrl, filterProjectsByCategory } from '../utils/contact';

function ProjectMockupPreview({ project }: { project: ProjectItem }) {
  const themeClasses: Record<
    ProjectItem['mockupTheme'],
    { frame: string; bar: string; title: string; sub: string; card: string; accent: string }
  > = {
    navy: {
      frame: 'bg-[#081331] text-white border-white/10',
      bar: 'border-white/15 text-slate-300',
      title: 'text-white',
      sub: 'text-slate-300',
      card: 'bg-white/10 border-white/15 text-white',
      accent: 'bg-white text-[#081331]',
    },
    ink: {
      frame: 'bg-[#0A0D14] text-white border-slate-800',
      bar: 'border-slate-800 text-slate-300',
      title: 'text-white',
      sub: 'text-slate-300',
      card: 'bg-white/5 border-white/10 text-white',
      accent: 'bg-[#173B8F] text-white',
    },
    light: {
      frame: 'bg-[#F8FAFC] text-[#0A0D14] border-slate-200',
      bar: 'border-slate-200 text-slate-600',
      title: 'text-[#0A0D14]',
      sub: 'text-slate-700',
      card: 'bg-white border-slate-200 text-[#0A0D14]',
      accent: 'bg-[#081331] text-white',
    },
    slate: {
      frame: 'bg-[#0F1F4A] text-white border-white/10',
      bar: 'border-white/15 text-slate-200',
      title: 'text-white',
      sub: 'text-slate-200',
      card: 'bg-[#081331]/80 border-white/15 text-white',
      accent: 'bg-white text-[#081331]',
    },
  };

  const styles = themeClasses[project.mockupTheme];

  return (
    <div
      className={`overflow-hidden rounded-xl border p-4 sm:p-5 ${styles.frame}`}
      aria-hidden="true"
    >
      <div className={`flex items-center justify-between border-b pb-3 text-[11px] font-medium ${styles.bar}`}>
        <span className="truncate">{project.client}</span>
        <span className="shrink-0">{project.categoryLabel}</span>
      </div>

      <div className="mt-4">
        <p className={`font-display text-sm font-bold leading-snug sm:text-base ${styles.title}`}>
          {project.mockupHeadline}
        </p>
        <p className={`mt-1.5 text-xs leading-relaxed ${styles.sub}`}>{project.mockupSubline}</p>

        <div className="mt-4 inline-flex rounded-md px-3 py-1.5 text-[11px] font-semibold whitespace-nowrap">
          <span className={`rounded-md px-3 py-1.5 ${styles.accent}`}>Solicitar avaliação</span>
        </div>
      </div>

      <div className="mt-5 grid grid-cols-3 gap-2">
        {project.mockupKpis.map((kpi) => (
          <div key={kpi.label} className={`rounded-lg border p-2.5 ${styles.card}`}>
            <div className="font-display text-xs font-bold tabular-nums sm:text-sm">
              {kpi.value}
            </div>
            <div className="mt-0.5 truncate text-[10px] opacity-80">{kpi.label}</div>
          </div>
        ))}
      </div>
    </div>
  );
}

export function PortfolioSection() {
  const [activeCategory, setActiveCategory] = useState<ProjectCategory>('todos');
  const [selectedProject, setSelectedProject] = useState<ProjectItem | null>(null);
  const shouldReduceMotion = useReducedMotion();

  const filteredProjects = filterProjectsByCategory(PROJECTS, activeCategory);
  const mainWhatsappHref = buildWhatsAppUrl(
    'Olá, AKB Digital! Vi os projetos do portfólio e quero solicitar um orçamento gratuito para o meu negócio.',
  );

  useEffect(() => {
    if (!selectedProject) return;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') {
        setSelectedProject(null);
      }
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [selectedProject]);

  return (
    <section id="projetos" className="border-b border-slate-200 bg-white py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 lg:flex-row lg:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-[#0F255C] sm:text-sm">
              Portfólio selecionado · Projetos com foco em resultado
            </p>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#0A0D14] [text-wrap:balance] sm:text-3xl lg:text-4xl">
              Sites e páginas criados para gerar autoridade e vendas reais.
            </h2>
          </div>

          <a
            href={mainWhatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-11 max-w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-5 py-3 text-center text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0F255C] sm:whitespace-nowrap sm:shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
          >
            <span>Solicitar orçamento gratuito no WhatsApp</span>
            <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </a>
        </div>

        {/* Interactive Category Filter Controls */}
        <div
          role="tablist"
          aria-label="Filtrar projetos por categoria"
          className="mt-10 flex flex-wrap items-center gap-1.5 rounded-xl bg-slate-100 p-1.5 sm:inline-flex"
        >
          {PORTFOLIO_CATEGORIES.map((cat) => {
            const isActive = activeCategory === cat.id;
            return (
              <button
                key={cat.id}
                type="button"
                role="tab"
                aria-selected={isActive}
                onClick={() => setActiveCategory(cat.id)}
                className={`min-h-10 rounded-lg px-4 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C] ${
                  isActive
                    ? 'bg-white text-[#081331] shadow-sm'
                    : 'text-slate-700 hover:text-[#081331]'
                }`}
              >
                {cat.label}
              </button>
            );
          })}
        </div>

        {/* Projects Grid */}
        <div className="mt-8 grid grid-cols-1 gap-8 lg:grid-cols-2" data-testid="portfolio-grid">
          {filteredProjects.map((project, idx) => (
            <motion.article
              key={project.id}
              layout={!shouldReduceMotion}
              initial={shouldReduceMotion ? false : { opacity: 0, y: 14 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{
                duration: 0.32,
                delay: shouldReduceMotion ? 0 : idx * 0.04,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-6 transition-colors duration-150 hover:border-[#081331]/40 sm:p-7"
            >
              <div>
                <ProjectMockupPreview project={project} />

                <div className="mt-6 flex flex-wrap items-center gap-2 text-xs font-medium text-slate-600">
                  <span>{project.segment}</span>
                  <span aria-hidden="true">·</span>
                  <span>{project.categoryLabel}</span>
                  <span aria-hidden="true">·</span>
                  <span className="tabular-nums">{project.year}</span>
                </div>

                <h3 className="mt-2 font-display text-xl font-bold tracking-tight text-[#0A0D14]">
                  {project.client} — {project.title}
                </h3>

                <p className="mt-2.5 text-sm leading-relaxed text-slate-700 sm:text-base">
                  {project.summary}
                </p>
              </div>

              <div className="mt-6 flex flex-col gap-4 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-between">
                <p className="text-sm font-bold text-[#081331] tabular-nums">
                  {project.primaryMetric}
                </p>

                <button
                  type="button"
                  onClick={() => setSelectedProject(project)}
                  className="inline-flex min-h-10 items-center justify-center rounded-lg border border-slate-300 bg-white px-4 py-2 text-xs font-semibold text-[#081331] transition-colors duration-150 hover:border-[#081331] hover:bg-slate-50 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
                >
                  Ver estudo de caso
                </button>
              </div>
            </motion.article>
          ))}
        </div>
      </div>

      {/* Case Study Detail Modal */}
      <AnimatePresence>
        {selectedProject && (
          <div
            className="fixed inset-0 z-50 flex items-center justify-center bg-[#050D24]/70 p-4 backdrop-blur-xs"
            role="dialog"
            aria-modal="true"
            aria-labelledby="project-modal-title"
            onClick={() => setSelectedProject(null)}
          >
            <motion.div
              initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.97, y: 8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={shouldReduceMotion ? undefined : { opacity: 0, scale: 0.97, y: 8 }}
              transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
              onClick={(event) => event.stopPropagation()}
              className="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-slate-200 bg-white p-6 shadow-2xl sm:p-8"
            >
              <div className="flex items-start justify-between gap-4 border-b border-slate-200 pb-4">
                <div>
                  <div className="flex flex-wrap items-center gap-2 text-xs font-medium text-slate-600">
                    <span>{selectedProject.segment}</span>
                    <span aria-hidden="true">·</span>
                    <span>{selectedProject.categoryLabel}</span>
                    <span aria-hidden="true">·</span>
                    <span className="tabular-nums">{selectedProject.year}</span>
                  </div>
                  <h3
                    id="project-modal-title"
                    className="mt-1.5 font-display text-xl font-bold tracking-tight text-[#0A0D14] sm:text-2xl"
                  >
                    {selectedProject.client} — {selectedProject.title}
                  </h3>
                </div>

                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  aria-label="Fechar detalhes do projeto"
                  className="inline-flex h-10 w-10 items-center justify-center rounded-lg border border-slate-200 text-slate-700 transition-colors hover:bg-slate-100 hover:text-[#0A0D14] shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
                >
                  <X className="h-5 w-5" aria-hidden="true" />
                </button>
              </div>

              <div className="mt-6">
                <ProjectMockupPreview project={selectedProject} />
              </div>

              <div className="mt-6 space-y-5">
                <div className="rounded-xl bg-[#F8FAFC] p-4 border border-slate-200">
                  <p className="text-xs font-semibold text-[#0F255C]">Resultado alcançado</p>
                  <p className="mt-1 font-display text-lg font-bold text-[#081331] tabular-nums">
                    {selectedProject.primaryMetric}
                  </p>
                </div>

                <div>
                  <h4 className="font-display text-sm font-bold text-[#0A0D14]">Desafio do cliente</h4>
                  <p className="mt-1 text-sm leading-relaxed text-slate-700">
                    {selectedProject.challenge}
                  </p>
                </div>

                <div>
                  <h4 className="font-display text-sm font-bold text-[#0A0D14]">
                    Solução estratégica AKB Digital
                  </h4>
                  <p className="mt-1 text-sm leading-relaxed text-slate-700">
                    {selectedProject.solution}
                  </p>
                </div>

                <div>
                  <h4 className="font-display text-sm font-bold text-[#0A0D14]">Entregas realizadas</h4>
                  <ul className="mt-2 space-y-1.5 text-sm text-slate-700">
                    {selectedProject.deliverables.map((item) => (
                      <li key={item} className="flex items-baseline gap-2">
                        <span className="font-bold text-[#0F255C]" aria-hidden="true">
                          —
                        </span>
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="mt-8 flex flex-col gap-3 border-t border-slate-200 pt-5 sm:flex-row sm:items-center sm:justify-between">
                <a
                  href={buildWhatsAppUrl(
                    `Olá, AKB Digital! Gostei do projeto "${selectedProject.client}" e gostaria de solicitar um orçamento gratuito parecido para o meu negócio.`,
                  )}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex min-h-11 max-w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-4 py-3 text-center text-sm font-semibold text-white transition-colors hover:bg-[#0F255C] sm:px-5 sm:whitespace-nowrap sm:shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
                >
                  <span>Solicitar orçamento gratuito no WhatsApp</span>
                  <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                </a>

                <button
                  type="button"
                  onClick={() => setSelectedProject(null)}
                  className="inline-flex min-h-11 items-center justify-center rounded-lg border border-slate-300 px-4 py-2.5 text-sm font-semibold text-slate-700 transition-colors hover:bg-slate-50 whitespace-nowrap shrink-0"
                >
                  Voltar ao portfólio
                </button>
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </section>
  );
}
