import { ArrowUpRight } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { DIFFERENTIATORS } from '../data/portfolioData';
import { buildWhatsAppUrl } from '../utils/contact';

export function AboutSection() {
  const shouldReduceMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl(
    'Olá, AKB Digital! Vi o site de vocês e gostaria de solicitar um orçamento gratuito para minha empresa.',
  );

  return (
    <section id="sobre" className="border-b border-slate-200 bg-white py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Story & Target Audience */}
          <motion.div
            initial={shouldReduceMotion ? false : { opacity: 0, y: 16 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true, amount: 0.2 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <p className="text-xs font-semibold tracking-wide text-[#0F255C] sm:text-sm">
              Sobre a AKB Digital · Atendimento em todo o Brasil
            </p>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#0A0D14] [text-wrap:balance] sm:text-3xl lg:text-4xl">
              Posicionamento sólido para quem não pode parecer amador online.
            </h2>

            <p className="mt-6 text-base leading-relaxed text-slate-700">
              A agência AKB Digital nasceu com o propósito de ajudar empresas a conquistarem a autoridade que merecem na internet. Somos especialistas em unir design de alto padrão, copywriting persuasivo e tecnologia de ponta para criar experiências digitais que não apenas impressionam visualmente, mas geram resultados reais e previsíveis no caixa do seu negócio.
            </p>

            <p className="mt-4 text-base leading-relaxed text-slate-700">
              Atuamos de forma consultiva com pequenas e médias empresas, prestadores de serviços, clínicas e profissionais liberais em todo o Brasil, transformando o site no principal canal de confiança e captação de clientes da sua operação.
            </p>

            <div className="mt-8">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-11 max-w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-5 py-3 text-center text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0F255C] sm:whitespace-nowrap sm:shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
              >
                <span>Solicitar orçamento gratuito no WhatsApp</span>
                <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right Column: Clean Editorial Numbered List of 5 Differentiators */}
          <div className="lg:col-span-7">
            <div className="border-t border-slate-200">
              {DIFFERENTIATORS.map((item, idx) => (
                <motion.div
                  key={item.number}
                  initial={shouldReduceMotion ? false : { opacity: 0, y: 12 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true, amount: 0.2 }}
                  transition={{
                    duration: 0.35,
                    delay: shouldReduceMotion ? 0 : idx * 0.05,
                    ease: [0.16, 1, 0.3, 1],
                  }}
                  className="grid grid-cols-1 gap-2 border-b border-slate-200 py-6 sm:grid-cols-12 sm:items-baseline sm:gap-6"
                >
                  <span className="font-display text-sm font-bold text-[#0F255C] tabular-nums sm:col-span-2">
                    {item.number}.
                  </span>
                  <div className="sm:col-span-10">
                    <h3 className="font-display text-lg font-bold text-[#0A0D14]">
                      {item.title}
                    </h3>
                    <p className="mt-1.5 text-sm leading-relaxed text-slate-700 sm:text-base">
                      {item.detail}
                    </p>
                  </div>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
