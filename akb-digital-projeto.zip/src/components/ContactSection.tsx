import { useEffect, useState, type FormEvent } from 'react';
import { ArrowUpRight, CheckCircle2, Instagram, Phone } from 'lucide-react';
import { SERVICES } from '../data/portfolioData';
import {
  buildLeadWhatsAppMessage,
  buildWhatsAppUrl,
  formatBrazilianPhone,
  INSTAGRAM_HANDLE,
  INSTAGRAM_URL,
  validateContactForm,
  WHATSAPP_DISPLAY,
  type ContactFormErrors,
  type ContactFormValues,
} from '../utils/contact';

interface ContactSectionProps {
  preselectedService: string;
}

export function ContactSection({ preselectedService }: ContactSectionProps) {
  const [values, setValues] = useState<ContactFormValues>({
    name: '',
    phone: '',
    businessSegment: '',
    service: preselectedService || SERVICES[0].title,
    message: '',
  });
  const [errors, setErrors] = useState<ContactFormErrors>({});
  const [submittedUrl, setSubmittedUrl] = useState<string | null>(null);

  useEffect(() => {
    if (preselectedService) {
      setValues((prev) => ({ ...prev, service: preselectedService }));
      setSubmittedUrl(null);
    }
  }, [preselectedService]);

  const handleSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const validationErrors = validateContactForm(values);
    if (Object.keys(validationErrors).length > 0) {
      setErrors(validationErrors);
      setSubmittedUrl(null);
      return;
    }

    setErrors({});
    const message = buildLeadWhatsAppMessage(values);
    const url = buildWhatsAppUrl(message);
    setSubmittedUrl(url);
  };

  const directWhatsappHref = buildWhatsAppUrl();

  return (
    <section id="contato" className="bg-white py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-12 lg:grid-cols-12 lg:gap-16">
          {/* Left Column: Direct Specialist Channels */}
          <div className="flex flex-col justify-between lg:col-span-5">
            <div>
              <p className="text-xs font-semibold tracking-wide text-[#0F255C] sm:text-sm">
                Contato direto · Orçamento sem compromisso
              </p>
              <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#0A0D14] [text-wrap:balance] sm:text-3xl lg:text-4xl">
                Solicite seu orçamento gratuito pelo WhatsApp.
              </h2>
              <p className="mt-4 text-base leading-relaxed text-slate-700">
                Preencha os dados ao lado para estruturar seu pedido ou fale diretamente conosco agora mesmo. Atendimento online para empresas e profissionais de todo o Brasil.
              </p>

              <div className="mt-8 space-y-5 border-t border-slate-200 pt-8">
                <div className="flex items-start gap-3.5">
                  <Phone className="mt-0.5 h-5 w-5 shrink-0 text-[#081331]" aria-hidden="true" />
                  <div>
                    <div className="text-xs font-semibold text-slate-600">WhatsApp comercial</div>
                    <a
                      href={directWhatsappHref}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-0.5 inline-block font-display text-lg font-bold text-[#081331] tabular-nums hover:underline"
                    >
                      {WHATSAPP_DISPLAY}
                    </a>
                  </div>
                </div>

                <div className="flex items-start gap-3.5">
                  <Instagram className="mt-0.5 h-5 w-5 shrink-0 text-[#081331]" aria-hidden="true" />
                  <div>
                    <div className="text-xs font-semibold text-slate-600">Instagram oficial</div>
                    <a
                      href={INSTAGRAM_URL}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="mt-0.5 inline-block font-display text-lg font-bold text-[#081331] hover:underline"
                    >
                      @{INSTAGRAM_HANDLE}
                    </a>
                  </div>
                </div>
              </div>
            </div>

            <div className="mt-8 rounded-2xl border border-slate-200 bg-[#F8FAFC] p-6">
              <p className="font-display text-sm font-bold text-[#081331]">
                Garantia de atendimento direto
              </p>
              <p className="mt-1.5 text-sm leading-relaxed text-slate-700">
                Prazo de entrega em até 7 dias úteis após alinhamento inicial, com ajustes garantidos até a sua aprovação final.
              </p>
            </div>
          </div>

          {/* Right Column: Validated Briefing Form */}
          <div className="lg:col-span-7">
            <div className="rounded-2xl border border-slate-200 bg-white p-6 sm:p-8">
              <h3 className="font-display text-xl font-bold text-[#0A0D14]">
                Briefing rápido do projeto
              </h3>
              <p className="mt-1 text-sm text-slate-600">
                Ao enviar, geramos uma mensagem organizada pronta para abrir no WhatsApp da AKB Digital.
              </p>

              <form onSubmit={handleSubmit} noValidate className="mt-6 space-y-5">
                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="contact-name"
                      className="block text-sm font-semibold text-[#0A0D14]"
                    >
                      Nome completo
                    </label>
                    <input
                      id="contact-name"
                      name="name"
                      type="text"
                      autoComplete="name"
                      value={values.name}
                      onChange={(e) => {
                        setValues((prev) => ({ ...prev, name: e.target.value }));
                        if (errors.name) setErrors((prev) => ({ ...prev, name: undefined }));
                      }}
                      placeholder="Ex.: Mariana Albuquerque"
                      aria-invalid={Boolean(errors.name)}
                      aria-describedby={errors.name ? 'error-contact-name' : undefined}
                      className="mt-1.5 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-[#0A0D14] placeholder:text-slate-400 focus:border-[#081331] focus:outline-none focus:ring-2 focus:ring-[#081331]/20"
                    />
                    {errors.name && (
                      <p id="error-contact-name" role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                        {errors.name}
                      </p>
                    )}
                  </div>

                  <div>
                    <label
                      htmlFor="contact-phone"
                      className="block text-sm font-semibold text-[#0A0D14]"
                    >
                      Seu WhatsApp (com DDD)
                    </label>
                    <input
                      id="contact-phone"
                      name="phone"
                      type="tel"
                      autoComplete="tel"
                      value={values.phone}
                      onChange={(e) => {
                        const formatted = formatBrazilianPhone(e.target.value);
                        setValues((prev) => ({ ...prev, phone: formatted }));
                        if (errors.phone) setErrors((prev) => ({ ...prev, phone: undefined }));
                      }}
                      placeholder="(82) 99999-9999"
                      aria-invalid={Boolean(errors.phone)}
                      aria-describedby={errors.phone ? 'error-contact-phone' : undefined}
                      className="mt-1.5 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-[#0A0D14] tabular-nums placeholder:text-slate-400 focus:border-[#081331] focus:outline-none focus:ring-2 focus:ring-[#081331]/20"
                    />
                    {errors.phone && (
                      <p id="error-contact-phone" role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                        {errors.phone}
                      </p>
                    )}
                  </div>
                </div>

                <div className="grid grid-cols-1 gap-5 sm:grid-cols-2">
                  <div>
                    <label
                      htmlFor="contact-segment"
                      className="block text-sm font-semibold text-[#0A0D14]"
                    >
                      Segmento da empresa (opcional)
                    </label>
                    <input
                      id="contact-segment"
                      name="businessSegment"
                      type="text"
                      value={values.businessSegment}
                      onChange={(e) =>
                        setValues((prev) => ({ ...prev, businessSegment: e.target.value }))
                      }
                      placeholder="Ex.: Clínica médica, Advocacia, Serviços"
                      className="mt-1.5 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-[#0A0D14] placeholder:text-slate-400 focus:border-[#081331] focus:outline-none focus:ring-2 focus:ring-[#081331]/20"
                    />
                  </div>

                  <div>
                    <label
                      htmlFor="contact-service"
                      className="block text-sm font-semibold text-[#0A0D14]"
                    >
                      Serviço de interesse
                    </label>
                    <select
                      id="contact-service"
                      name="service"
                      value={values.service}
                      onChange={(e) => {
                        setValues((prev) => ({ ...prev, service: e.target.value }));
                        if (errors.service) setErrors((prev) => ({ ...prev, service: undefined }));
                      }}
                      aria-invalid={Boolean(errors.service)}
                      aria-describedby={errors.service ? 'error-contact-service' : undefined}
                      className="mt-1.5 block min-h-11 w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-[#0A0D14] focus:border-[#081331] focus:outline-none focus:ring-2 focus:ring-[#081331]/20"
                    >
                      {SERVICES.map((service) => (
                        <option key={service.id} value={service.title}>
                          {service.title}
                        </option>
                      ))}
                    </select>
                    {errors.service && (
                      <p id="error-contact-service" role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                        {errors.service}
                      </p>
                    )}
                  </div>
                </div>

                <div>
                  <label
                    htmlFor="contact-message"
                    className="block text-sm font-semibold text-[#0A0D14]"
                  >
                    Conte brevemente o que você precisa
                  </label>
                  <textarea
                    id="contact-message"
                    name="message"
                    rows={4}
                    value={values.message}
                    onChange={(e) => {
                      setValues((prev) => ({ ...prev, message: e.target.value }));
                      if (errors.message) setErrors((prev) => ({ ...prev, message: undefined }));
                    }}
                    placeholder="Ex.: Preciso de um site novo para minha clínica transmitir mais confiança e receber agendamentos pelo WhatsApp."
                    aria-invalid={Boolean(errors.message)}
                    aria-describedby={errors.message ? 'error-contact-message' : undefined}
                    className="mt-1.5 block w-full rounded-lg border border-slate-300 bg-white px-3.5 py-2.5 text-sm text-[#0A0D14] placeholder:text-slate-400 focus:border-[#081331] focus:outline-none focus:ring-2 focus:ring-[#081331]/20"
                  />
                  {errors.message && (
                    <p id="error-contact-message" role="alert" className="mt-1.5 text-xs font-medium text-red-700">
                      {errors.message}
                    </p>
                  )}
                </div>

                <div className="pt-1">
                  <button
                    type="submit"
                    className="inline-flex min-h-12 w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-4 py-3 text-center text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0F255C] sm:px-6 sm:whitespace-nowrap focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
                  >
                    <span>Solicitar orçamento gratuito no WhatsApp</span>
                    <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
                  </button>
                </div>

                {submittedUrl && (
                  <div
                    role="status"
                    className="rounded-xl border border-[#081331]/25 bg-[#F8FAFC] p-4"
                  >
                    <div className="flex items-start gap-3">
                      <CheckCircle2
                        className="mt-0.5 h-5 w-5 shrink-0 text-[#081331]"
                        aria-hidden="true"
                      />
                      <div className="flex-1">
                        <p className="font-display text-sm font-bold text-[#081331]">
                          Briefing preparado com sucesso
                        </p>
                        <p className="mt-1 text-xs leading-relaxed text-slate-700 sm:text-sm">
                          Clique no botão abaixo para abrir a conversa no WhatsApp da AKB Digital com seus dados já preenchidos.
                        </p>
                        <a
                          href={submittedUrl}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="mt-3 inline-flex min-h-10 items-center justify-center gap-1.5 rounded-lg bg-[#081331] px-4 py-2 text-xs font-semibold text-white transition-colors hover:bg-[#0F255C] whitespace-nowrap"
                        >
                          <span>Abrir conversa no WhatsApp agora</span>
                          <ArrowUpRight className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                        </a>
                      </div>
                    </div>
                  </div>
                )}
              </form>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
