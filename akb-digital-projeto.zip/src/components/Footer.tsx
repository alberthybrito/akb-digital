import { INSTAGRAM_HANDLE, INSTAGRAM_URL, WHATSAPP_DISPLAY, buildWhatsAppUrl } from '../utils/contact';

export function Footer() {
  const year = new Date().getFullYear();

  return (
    <footer className="border-t border-slate-200 bg-[#050D24] py-12 text-slate-300">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-8 md:flex-row md:items-center">
          <div>
            <a
              href="#inicio"
              className="font-display text-lg font-extrabold tracking-tight text-white"
            >
              AKB Digital
            </a>
            <p className="mt-1.5 text-sm text-slate-300">
              Desenvolvimento Web, Criação de Sites e Posicionamento Digital · Atendimento online para todo o Brasil
            </p>
          </div>

          <nav aria-label="Links do rodapé" className="flex flex-wrap items-center gap-6 text-sm">
            <a href="#sobre" className="transition-colors hover:text-white whitespace-nowrap">
              Sobre
            </a>
            <a href="#servicos" className="transition-colors hover:text-white whitespace-nowrap">
              Serviços
            </a>
            <a href="#projetos" className="transition-colors hover:text-white whitespace-nowrap">
              Projetos
            </a>
            <a href="#depoimentos" className="transition-colors hover:text-white whitespace-nowrap">
              Depoimentos
            </a>
            <a href="#contato" className="transition-colors hover:text-white whitespace-nowrap">
              Contato
            </a>
          </nav>
        </div>

        <div className="mt-8 flex flex-col justify-between gap-4 border-t border-white/15 pt-6 text-xs text-slate-400 sm:flex-row sm:items-center">
          <p>© {year} AKB Digital. Todos os direitos reservados.</p>
          <div className="flex flex-wrap items-center gap-4">
            <a
              href={buildWhatsAppUrl()}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-200 transition-colors hover:text-white tabular-nums"
            >
              WhatsApp: {WHATSAPP_DISPLAY}
            </a>
            <span aria-hidden="true">·</span>
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="text-slate-200 transition-colors hover:text-white"
            >
              Instagram: @{INSTAGRAM_HANDLE}
            </a>
          </div>
        </div>
      </div>
    </footer>
  );
}
