import { MessageCircle } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { buildWhatsAppUrl } from '../utils/contact';

export function FloatingWhatsApp() {
  const shouldReduceMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl();

  return (
    <motion.a
      href={whatsappHref}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Solicitar orçamento gratuito no WhatsApp"
      initial={shouldReduceMotion ? false : { opacity: 0, scale: 0.9 }}
      animate={{ opacity: 1, scale: 1 }}
      whileHover={shouldReduceMotion ? undefined : { scale: 1.04 }}
      whileTap={shouldReduceMotion ? undefined : { scale: 0.97 }}
      transition={{ duration: 0.2, ease: [0.16, 1, 0.3, 1] }}
      className="fixed right-4 bottom-4 z-40 inline-flex h-12 w-12 items-center justify-center gap-2 rounded-full border border-white/20 bg-[#081331] text-xs font-semibold text-white shadow-lg transition-colors duration-150 hover:bg-[#0F255C] sm:right-5 sm:bottom-5 sm:h-11 sm:w-auto sm:px-4 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
    >
      <MessageCircle className="h-5 w-5 shrink-0 sm:h-4 sm:w-4" aria-hidden="true" />
      <span className="hidden sm:inline whitespace-nowrap">WhatsApp</span>
    </motion.a>
  );
}
