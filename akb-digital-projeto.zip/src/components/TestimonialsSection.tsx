import { ArrowUpRight } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { TESTIMONIALS } from '../data/portfolioData';
import { buildWhatsAppUrl } from '../utils/contact';

export function TestimonialsSection() {
  const shouldReduceMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl(
    'Olá, AKB Digital! Quero profissionalizar a presença online da minha empresa e solicitar um orçamento gratuito.',
  );

  return (
    <section id="depoimentos" className="border-b border-slate-200 bg-[#081331] py-16 text-white sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="max-w-2xl">
          <p className="text-xs font-semibold tracking-wide text-slate-300 sm:text-sm">
            Prova real de clientes · Empresas, clínicas e profissionais liberais
          </p>
          <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-white [text-wrap:balance] sm:text-3xl lg:text-4xl">
            Quem investiu em posicionamento digital já colhe resultados no caixa.
          </h2>
        </div>

        <div className="mt-12 grid grid-cols-1 gap-6 lg:grid-cols-3">
          {TESTIMONIALS.map((item, idx) => (
            <motion.blockquote
              key={item.id}
              initial={shouldReduceMotion ? false : { opacity: 0, y: 14 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, amount: 0.2 }}
              transition={{
                duration: 0.38,
                delay: shouldReduceMotion ? 0 : idx * 0.06,
                ease: [0.16, 1, 0.3, 1],
              }}
              className="flex flex-col justify-between rounded-2xl border border-white/15 bg-[#050D24] p-7"
            >
              <div>
                <p className="text-sm font-semibold text-white">{item.outcome}</p>
                <p className="mt-4 text-sm leading-relaxed text-slate-200 sm:text-base">
                  “{item.quote}”
                </p>
              </div>

              <footer className="mt-8 border-t border-white/15 pt-5">
                <div className="font-display text-sm font-bold text-white">{item.author}</div>
                <div className="mt-0.5 text-xs text-slate-300">
                  {item.role} · {item.company}
                </div>
                <div className="mt-0.5 text-xs text-slate-400">{item.location}</div>
              </footer>
            </motion.blockquote>
          ))}
        </div>

        {/* High-Conversion Objection-Handling Strip */}
        <div className="mt-12 flex flex-col items-start justify-between gap-6 rounded-2xl border border-white/15 bg-white p-7 text-[#0A0D14] sm:flex-row sm:items-center sm:p-8">
          <div className="max-w-xl">
            <h3 className="font-display text-xl font-bold tracking-tight text-[#081331] sm:text-2xl">
              Pronto para ter um site à altura da qualidade do seu serviço?
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-slate-700 sm:text-base">
              Converse diretamente com um especialista da AKB Digital, receba um diagnóstico gratuito e tenha seu projeto entregue em até 7 dias úteis.
            </p>
          </div>

          <a
            href={whatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-12 max-w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-5 py-3.5 text-center text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0F255C] sm:px-6 sm:whitespace-nowrap sm:shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
          >
            <span>Solicitar orçamento gratuito no WhatsApp</span>
            <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </a>
        </div>
      </div>
    </section>
  );
}
