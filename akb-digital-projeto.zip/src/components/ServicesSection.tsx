import { ArrowDownRight, ArrowUpRight } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { SERVICES } from '../data/portfolioData';
import { buildServiceWhatsAppUrl, buildWhatsAppUrl } from '../utils/contact';

interface ServicesSectionProps {
  onSelectServiceForForm: (serviceTitle: string) => void;
}

export function ServicesSection({ onSelectServiceForForm }: ServicesSectionProps) {
  const shouldReduceMotion = useReducedMotion();
  const mainWhatsappHref = buildWhatsAppUrl(
    'Olá, AKB Digital! Gostaria de entender qual serviço faz mais sentido para minha empresa e solicitar um orçamento gratuito.',
  );

  return (
    <section id="servicos" className="border-b border-slate-200 bg-[#F8FAFC] py-16 sm:py-20 lg:py-24">
      <div className="mx-auto max-w-6xl px-4 sm:px-6 lg:px-8">
        <div className="flex flex-col justify-between gap-6 md:flex-row md:items-end">
          <div className="max-w-2xl">
            <p className="text-xs font-semibold tracking-wide text-[#0F255C] sm:text-sm">
              Soluções sob medida · Estratégia, Design e Código
            </p>
            <h2 className="mt-3 font-display text-2xl font-bold tracking-tight text-[#0A0D14] [text-wrap:balance] sm:text-3xl lg:text-4xl">
              Serviços desenhados para transformar audiência em faturamento.
            </h2>
          </div>

          <a
            href={mainWhatsappHref}
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex min-h-11 max-w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-5 py-3 text-center text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0F255C] sm:whitespace-nowrap sm:shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
          >
            <span>Solicitar orçamento gratuito no WhatsApp</span>
            <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
          </a>
        </div>

        {/* Asymmetric Bento Grid: 2 High-Impact Navy Featured Cards + 4 Clean Structural White Cards */}
        <div className="mt-12 grid grid-cols-1 gap-6 md:grid-cols-2">
          {SERVICES.map((service, idx) => {
            const isFeatured = Boolean(service.featured);
            return (
              <motion.article
                key={service.id}
                initial={shouldReduceMotion ? false : { opacity: 0, y: 14 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, amount: 0.15 }}
                transition={{
                  duration: 0.38,
                  delay: shouldReduceMotion ? 0 : idx * 0.04,
                  ease: [0.16, 1, 0.3, 1],
                }}
                className={
                  isFeatured
                    ? 'flex flex-col justify-between rounded-2xl bg-[#081331] p-7 text-white sm:p-8'
                    : 'flex flex-col justify-between rounded-2xl border border-slate-200 bg-white p-7 text-[#0A0D14] sm:p-8'
                }
              >
                <div>
                  <div className="flex items-center justify-between gap-4">
                    <span
                      className={`font-display text-sm font-bold tabular-nums ${
                        isFeatured ? 'text-slate-300' : 'text-[#0F255C]'
                      }`}
                    >
                      {service.number}.
                    </span>
                    <span
                      className={`text-xs font-medium ${
                        isFeatured ? 'text-slate-300' : 'text-slate-600'
                      }`}
                    >
                      {service.shortLabel}
                    </span>
                  </div>

                  <h3
                    className={`mt-4 font-display text-xl font-bold tracking-tight sm:text-2xl ${
                      isFeatured ? 'text-white' : 'text-[#0A0D14]'
                    }`}
                  >
                    {service.title}
                  </h3>

                  <p
                    className={`mt-3 text-sm leading-relaxed sm:text-base ${
                      isFeatured ? 'text-slate-200' : 'text-slate-700'
                    }`}
                  >
                    {service.description}
                  </p>
                </div>

                <div
                  className={`mt-8 flex flex-col gap-4 border-t pt-5 ${
                    isFeatured ? 'border-white/15' : 'border-slate-200'
                  }`}
                >
                  <p
                    className={`text-xs font-medium sm:text-sm ${
                      isFeatured ? 'text-slate-200' : 'text-slate-700'
                    }`}
                  >
                    Resultado esperado: {service.outcome}
                  </p>

                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <a
                      href={buildServiceWhatsAppUrl(service.title)}
                      target="_blank"
                      rel="noopener noreferrer"
                      className={`inline-flex min-h-10 items-center justify-center gap-1.5 rounded-lg px-4 py-2 text-xs font-semibold transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 ${
                        isFeatured
                          ? 'bg-white text-[#081331] hover:bg-slate-100 focus-visible:outline-white'
                          : 'bg-[#081331] text-white hover:bg-[#0F255C] focus-visible:outline-[#0F255C]'
                      }`}
                    >
                      <span>Orçamento no WhatsApp</span>
                      <ArrowUpRight className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    </a>

                    <button
                      type="button"
                      onClick={() => onSelectServiceForForm(service.title)}
                      className={`inline-flex min-h-10 items-center gap-1 text-xs font-semibold underline-offset-4 transition-colors hover:underline whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 ${
                        isFeatured
                          ? 'text-slate-200 hover:text-white focus-visible:outline-white'
                          : 'text-[#0F255C] hover:text-[#081331] focus-visible:outline-[#0F255C]'
                      }`}
                    >
                      <span>Enviar briefing no site</span>
                      <ArrowDownRight className="h-3.5 w-3.5 shrink-0" aria-hidden="true" />
                    </button>
                  </div>
                </div>
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
