import { useState } from 'react';
import { ArrowRight, ArrowUpRight } from 'lucide-react';
import { motion, useReducedMotion } from 'motion/react';
import { HERO_METRICS } from '../data/portfolioData';
import { buildWhatsAppUrl } from '../utils/contact';

export function HeroSection() {
  const [logoFailed, setLogoFailed] = useState(false);
  const shouldReduceMotion = useReducedMotion();
  const whatsappHref = buildWhatsAppUrl();

  return (
    <section id="inicio" className="border-b border-slate-200 bg-white">
      <div className="mx-auto max-w-6xl px-4 pt-10 pb-10 sm:px-6 sm:pt-14 sm:pb-12 lg:px-8 lg:pt-14 lg:pb-12">
        <div className="grid grid-cols-1 items-stretch gap-8 lg:grid-cols-12 lg:gap-12">
          {/* Left Column: Core Proposition & Primary Conversion */}
          <motion.div
            initial={shouldReduceMotion ? false : { opacity: 0, y: 14 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.45, ease: [0.16, 1, 0.3, 1] }}
            className="flex flex-col justify-between lg:col-span-7"
          >
            <div>
              <p className="text-xs font-semibold tracking-wide text-[#0F255C] sm:text-sm">
                Desenvolvimento Web e Posicionamento Digital · Atendimento online para todo o Brasil
              </p>

              <h1
                className="mt-4 font-display font-extrabold tracking-tight text-[#0A0D14] [text-wrap:balance]"
                style={{ fontSize: 'clamp(2rem, 3.8vw, 3.25rem)', lineHeight: 1.08 }}
              >
                Transformamos visitantes em clientes com sites rápidos, estratégicos e feitos para vender.
              </h1>

              <p className="mt-5 max-w-2xl text-base leading-relaxed text-slate-700 sm:text-lg">
                Desenvolvemos sites exclusivos, páginas de vendas e presença local no Google para pequenas e médias empresas, clínicas e profissionais liberais que querem transmitir confiança imediata e gerar contatos qualificados todos os dias.
              </p>
            </div>

            <div className="mt-7 flex flex-col gap-3 sm:flex-row sm:items-center sm:gap-4">
              <a
                href={whatsappHref}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex min-h-12 max-w-full items-center justify-center gap-2 rounded-lg bg-[#081331] px-4 py-3 text-center text-sm font-semibold text-white transition-colors duration-150 hover:bg-[#0F255C] sm:px-6 sm:whitespace-nowrap sm:shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
              >
                <span>Solicitar orçamento gratuito no WhatsApp</span>
                <ArrowUpRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>

              <a
                href="#projetos"
                className="inline-flex min-h-12 items-center justify-center gap-2 rounded-lg border border-slate-300 bg-white px-5 py-3 text-sm font-semibold text-[#0A0D14] transition-colors duration-150 hover:border-[#081331] hover:bg-slate-50 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F255C]"
              >
                <span>Explorar projetos</span>
                <ArrowRight className="h-4 w-4 shrink-0" aria-hidden="true" />
              </a>
            </div>
          </motion.div>

          {/* Right Column: Official AKB Digital Navy Brand Anchor */}
          <motion.div
            initial={shouldReduceMotion ? false : { opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.08, ease: [0.16, 1, 0.3, 1] }}
            className="lg:col-span-5"
          >
            <div className="flex h-full flex-col justify-between overflow-hidden rounded-2xl bg-[#061030] p-6 text-white sm:p-7">
              <div className="flex items-center justify-between border-b border-white/15 pb-3.5 text-xs font-medium text-slate-200">
                <span>AKB Digital</span>
                <span>Autoridade e Conversão</span>
              </div>

              <div className="my-4 flex flex-1 items-center justify-center">
                {!logoFailed ? (
                  <img
                    src="/assets/aistudio/logo_definitiva_2_1f27a1b3.png"
                    alt="Logotipo AKB Digital — Conectando sua empresa ao topo local"
                    referrerPolicy="no-referrer"
                    onError={() => setLogoFailed(true)}
                    className="max-h-56 w-auto object-contain sm:max-h-64"
                  />
                ) : (
                  <div className="flex flex-col items-center justify-center rounded-xl border border-white/15 bg-[#050D24] px-8 py-12 text-center">
                    <span className="font-display text-3xl font-extrabold tracking-tight text-white">
                      AKB DIGITAL
                    </span>
                    <span className="mt-2 text-xs tracking-widest text-slate-300">
                      CONECTANDO SUA EMPRESA AO TOPO LOCAL
                    </span>
                  </div>
                )}
              </div>

              <div className="border-t border-white/15 pt-3.5 text-xs leading-relaxed text-slate-200">
                <div className="flex flex-wrap items-center justify-center gap-x-3 gap-y-1">
                  <span>Design exclusivo</span>
                  <span aria-hidden="true">·</span>
                  <span>Copywriting persuasivo</span>
                  <span aria-hidden="true">·</span>
                  <span>SEO local</span>
                </div>
              </div>
            </div>
          </motion.div>
        </div>

        {/* Full-Width Quantitative Proof Strip Below Hero Split */}
        <div className="mt-10 grid grid-cols-1 gap-6 border-t border-slate-200 pt-7 sm:grid-cols-2 lg:grid-cols-4 lg:gap-8">
          {HERO_METRICS.map((metric) => (
            <div key={metric.value} className="flex flex-col gap-1">
              <span className="font-display text-xl font-bold tracking-tight text-[#081331] tabular-nums sm:text-2xl">
                {metric.value}
              </span>
              <span className="text-sm text-slate-700">{metric.label}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
